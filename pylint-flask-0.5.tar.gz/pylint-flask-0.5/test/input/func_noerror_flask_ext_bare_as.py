'''Ensure that pylint finds the exported methods from flask.ext.'''

import flask.ext.admin as admin, flask.ext.wtf as wtf

A = admin
W = wtf

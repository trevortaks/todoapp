'''Ensure that pylint finds the exported methods from flask.ext.'''

from flask.ext.wtf import Form

MYFORM = Form
